LAPDOG — HANDOFF PACKAGE
========================

You've received two ZIPs. Use them as follows.

────────────────────────────────────────────────
1. lapdog-shopify-theme.zip  (1.4 MB)   ← UPLOAD THIS TO SHOPIFY
────────────────────────────────────────────────
  This is the Shopify-compatible theme (Online Store 2.0 / Liquid).

  How to install:
    1. Shopify Admin  →  Online Store  →  Themes
    2. Scroll to "Theme library"  →  "Add theme"  →  "Upload zip file"
    3. Choose  lapdog-shopify-theme.zip
    4. Once uploaded, click  "Actions" → "Publish"

  Once installed:
    • Create Collections named "Tees", "Caps", "Accessories",
      "Outerwear", "Sale", etc. Upload one hero image per collection.
    • Add your products (Shopify Admin → Products). The theme uses
      product.featured_image; if a product has no image, a branded
      placeholder shows automatically.
    • Add Pages for: About, Lookbook, Community, Collaborations,
      Contact, Wholesale Inquiry, FAQ, Size Guide, Care, Shipping,
      Returns, Privacy Policy, Terms of Service, Cookie Policy.
      Use the copy from the HTML preview ZIP (below) as a starter —
      paste each page's body into a Shopify Page.
    • Create a Blog named "Journal" with 6 starter articles
      (copy from the HTML preview).
    • Under  Navigation, wire the main menu to your new links.
    • Theme settings (Customize theme):
        - Colors:  #FAF6E7 cream, #1E1EF0 cobalt, #0A0A0A ink
        - Logo:    upload your LapDog wordmark (SVG or PNG)
        - Favicon: SVG version is included in assets/favicon.svg

  Theme contains:
    layout/          → theme.liquid (site chrome)
    sections/        → 15 sections + header-group / footer-group
    snippets/        → product-card, meta-tags
    templates/       → index / product / collection / cart / page /
                        blog / article / search / 404 / list-collections
                        + customers/{login,register,account,orders,addresses,
                                    reset_password,activate_account}
    assets/          → base.css, global.js, 6 AI-generated hero JPEGs, favicon
    config/          → settings_schema.json, settings_data.json
    locales/         → en.default.json

────────────────────────────────────────────────
2. lapdog-preview-html.zip  ← REFERENCE ONLY
────────────────────────────────────────────────
  A static HTML version of every page (53 pages) that mirrors the
  Shopify build. Open  preview/index.html  in a browser to see the
  full design, or use it as content reference when populating your
  Shopify Admin.

  Includes:
    • Home
    • Shop All + 8 Collections (Tees, Caps, Accessories, Outerwear,
      Heavyweight subset, Boxy subset, Sale, plus the drop)
    • 5 Product pages
    • Lookbook Vol. 03 + Chapter II
    • Drop landing + Vol. 02 archive + first-access signup
    • Journal index + 6 articles
    • About, Contact, Wholesale Inquiry
    • Sign in, Register, Forgot Password, Account, Orders, Addresses, Wishlist
    • Cart, Checkout, Order Confirmation, Track Order, Search
    • Community, Collaborations
    • FAQ, Size Guide, Care
    • Shipping, Returns, Privacy Policy, Terms, Cookies
    • 404

  These pages use the same design system as the Shopify theme, so
  everything you see there will render identically once your Shopify
  content is populated.

────────────────────────────────────────────────
Placeholders you must replace
────────────────────────────────────────────────
  • [YOUR LEGAL ENTITY]        in privacy policy
  • [YOUR REGISTERED ADDRESS]  in privacy policy
  • [YOUR JURISDICTION]        in terms of service
  • [YOUR COURT SEAT]          in terms of service
  • email addresses (hello@, care@, wholesale@, press@, privacy@, legal@)
    — set these up on your domain or forward to a single inbox
  • Product images — every product needs at least one photo when you
    have samples. Until then the SVG placeholder shows automatically.
  • Domain — currency currently ₹ (INR) is used in the preview. Once
    the theme is published on Shopify, Shopify's automatic currency
    formatting takes over based on your store settings.

────────────────────────────────────────────────
Design system
────────────────────────────────────────────────
  Palette derived from your logo:
    Cream    #FAF6E7   (background)
    Cobalt   #1E1EF0   (primary accent)
    Ink      #0A0A0A   (text, dark surfaces)

  Typography — mirrors the dual personality of the LapDog wordmark:
    Playfair Display Italic  →  the "Lap" (serif italic)
    Inter Black              →  the "Dog" (bold sans)
    JetBrains Mono           →  eyebrows, metadata, buttons

  Aesthetic: minimal editorial luxury base (Kith / FOG mood) with
  streetwear energy from bold typography, marquees, and the cobalt
  accents. All hero imagery generated with Nano Banana 2 and
  compressed for web (avg ~250 KB per image).

────────────────────────────────────────────────
Support
────────────────────────────────────────────────
  If you need this ported to a different theme engine, get the theme
  re-generated with different collections, or need help with the
  Shopify upload — reply in the same session and continue.

  Enjoy the pack.
